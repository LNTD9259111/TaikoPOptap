import json,re,math
from pathlib import Path
from collections import Counter
from tja2fumen.parsers import parse_fumen
W=Path('/workspace/yugen-work')
text=(W/'yugen.tja').read_text(encoding='utf-8-sig'); courses={};meta={};cur=None;active=False;bar='';roll=None
commands=set()
for line in text.splitlines():
 line=line.split('//',1)[0].strip()
 if not line:continue
 if line.startswith('COURSE:'):
  assert not active;cur=line[7:].strip();courses[cur]={'events':[],'rolls':[],'measures':0};continue
 if ':' in line and not line.startswith('#'):
  k,v=line.split(':',1)
  if cur:courses[cur][k]=v
  else:meta[k]=v
  continue
 if line.startswith('#'):
  command,_,arg=line.partition(' ');commands.add(command)
  assert not bar
  if command=='#START':assert not active;active=True;bpm=float(meta['BPM']);sig=1;time=-float(meta['OFFSET'])*1000;gogo=False;roll=None
  elif command=='#END':assert active and roll is None;active=False;courses[cur]['end_ms']=time
  elif command=='#BPMCHANGE':bpm=float(arg);assert bpm>0
  elif command=='#MEASURE':a,b=map(int,arg.split('/'));assert a>0 and b>0;sig=a/b
  elif command=='#GOGOSTART':gogo=True
  elif command=='#GOGOEND':gogo=False
  else:raise ValueError('Unsupported command '+command)
  continue
 assert active
 for c in line:
  if c!=',': assert c in '0123456789';bar+=c;continue
  dur=240000/bpm*sig
  for i,n in enumerate(bar):
   at=time+i/len(bar)*dur
   if n in '1234':courses[cur]['events'].append({'type':n,'ms':at,'gogo':gogo})
   elif n in '56':assert roll is None;roll={'type':n,'ms':at,'gogo':gogo};courses[cur]['events'].append(roll)
   elif n=='8':assert roll is not None;roll['duration']=at-roll['ms'];courses[cur]['rolls'].append(roll.copy());roll=None
   elif n!='0':raise ValueError('Unexpected note '+n)
  time+=dur;bar='';courses[cur]['measures']+=1
assert not active and not bar and set(courses)=={'Easy','Normal','Hard','Oni'}
assert meta['WAVE']=='Yuugen no Ran.ogg'
report={'metadata':meta,'commands':sorted(commands),'courses':{}}
maptypes={'Don':'1','Don2':'1','Don3':'1','Ka':'2','Ka2':'2','DON':'3','KA':'4','Drumroll':'5','DRUMROLL':'6'}
for name,suffix in [('Easy','e'),('Normal','n'),('Hard','h'),('Oni','m')]:
 c=courses[name]; f=parse_fumen(str(W/f'yugen_{suffix}.bin')); actual=[]
 assert len(f.measures)==c['measures']
 for m in f.measures:
  for n in m.branches['normal'].notes:actual.append({'type':maptypes[n.note_type],'ms':m.offset_start+240000/m.bpm+n.pos,'gogo':m.gogo,'duration':n.duration})
 assert len(actual)==len(c['events'])
 err=0
 for x,y in zip(c['events'],actual):
  assert x['type']==y['type'] and x['gogo']==y['gogo'];e=abs(x['ms']-y['ms']);assert e<.02;err=max(err,e)
  if 'duration' in x:assert abs(x['duration']-y['duration'])<1.01
 hits=[n for n in c['events'] if n['type'] in '1234']
 assert max(e['ms']+e.get('duration',0) for e in c['events'])<126690.454
 report['courses'][name]={'stars':int(c['LEVEL']),'measures':c['measures'],'hit_notes':len(hits),'drumrolls':len(c['rolls']),'first_note_seconds':hits[0]['ms']/1000,'last_hit_seconds':hits[-1]['ms']/1000,'last_roll_end_seconds':max(r['ms']+r['duration'] for r in c['rolls'])/1000,'chart_end_seconds':c['end_ms']/1000,'max_conversion_timing_error_ms':err,'conversion':'passed','device_install_and_play_to_results':'NOT RUN'}
(W/'chart-validation.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':print(json.dumps(report,indent=2))
