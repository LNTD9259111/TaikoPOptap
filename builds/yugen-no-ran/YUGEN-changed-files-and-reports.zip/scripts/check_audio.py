import wave,json
from pathlib import Path
import numpy as np
W=Path('/workspace/yugen-work')
def read(p):
 with wave.open(str(p)) as w:
  assert w.getsampwidth()==2
  return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').reshape(-1,w.getnchannels()).astype(float),w.getframerate()
a,ar=read(W/'yugen.wav');b,br=read(W/'audio-roundtrip');assert ar==br==44100
print('samples original/decoded',len(a),len(b))
# Compare early non-silent material using FFT cross-correlation; check encoder introduces no delay.
x=a[ar:ar*6].mean(axis=1);y=b[ar:ar*6].mean(axis=1);n=1<<((len(x)*2-1).bit_length())
c=np.fft.irfft(np.fft.rfft(y,n)*np.conj(np.fft.rfft(x,n)),n);lag=int(np.argmax(c));lag=lag if lag<n//2 else lag-n
assert lag==0,lag
frames=min(len(a),len(b));a=a[:frames];b=b[:frames]
err=np.mean((a-b)**2);snr=float(10*np.log10(np.mean(a*a)/err));assert snr>25
assert np.max(np.abs(b))>100 and abs(len(b)/br-126.690454)<.05
r={'ogg_codec':'Vorbis','channels':2,'sample_rate':ar,'source_pcm_samples':len(a),'decoded_acb_samples':len(b),'duration_seconds':frames/ar,'encoding':'HCA 0x0200, highest quality, embedded AFS2 in ACB','cue':'song_yugen','cue_id':0,'external_awb_required':False,'pcm_lag_samples':lag,'roundtrip_snr_db':snr,'checks':'passed','device_audio_and_chart_sync':'NOT RUN'}
(W/'audio-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
