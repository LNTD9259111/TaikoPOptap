import hashlib,gzip,json
from pathlib import Path
from Crypto.Cipher import AES
ROOT=Path('/workspace/TaikoPOptap')
META=ROOT/'extracted/Payload/BNEI0361.app/Data/Managed/Metadata/global-metadata.dat'
def key():
 b=META.read_bytes(); target='7bc37daea3795d08ae97f02f2a804692f6576cca081b74f7342c07dd02f9f562'
 for i in range(len(b)-15):
  if hashlib.sha256(b[i:i+16]).hexdigest()==target:
   a,c=0,1; out=[]
   for v in b[i:i+16]:out.append(v^(a&255));a,c=c,a+c
   return bytes(out)
 raise ValueError('aesVal not found')
KEY=key()
def decrypt(b):
 return AES.new(KEY,AES.MODE_CBC,b[:16]).decrypt(b[16:])
def encrypt(b):
 # Reader uses PaddingMode.None, so pad data to whole blocks with zeros.
 iv=hashlib.sha256(b).digest()[:16];b+=bytes((-len(b))%16)
 return iv+AES.new(KEY,AES.MODE_CBC,iv).encrypt(b)
def decode_json(b):return json.loads(gzip.decompress(decrypt(b)))
def encode_json(d):return encrypt(gzip.compress(json.dumps(d,ensure_ascii=False,separators=(',',':')).encode(),mtime=0))
if __name__=='__main__':
 for f in (ROOT/'extracted/Payload/BNEI0361.app/Data/Raw/ReadAssets').glob('*.bin'):
  try:
   d=decode_json(f.read_bytes());Path('/workspace/yugen-work/'+f.stem+'.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
   print(f.name,type(d).__name__,list(d)[:3] if isinstance(d,dict) else len(d))
  except Exception as e: print(f.name,type(e).__name__,str(e))
