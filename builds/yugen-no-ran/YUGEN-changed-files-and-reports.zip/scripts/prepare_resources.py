import json,math,copy,zipfile
from pathlib import Path
from tja2fumen import convert_and_write
from tja2fumen.parsers import parse_tja
from resource_codec import decode_json,encode_json
from validate_chart import courses
W=Path('/workspace/yugen-work');O=W/'resources';R='Payload/BNEI0361.app/Data/Raw/'
def put(n,b):
 p=O/R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def estimate(events,init,diff):
 # Conventional TJA combo scoring estimate; not an official game leaderboard target.
 score=0;combo=0
 for e in events:
  if e['type'] not in '1234':continue
  combo+=1;v=init+diff*min(combo//10,10)
  if e['gogo']:v=math.floor(v*1.2/10)*10
  if e['type'] in '34':v*=2
  score+=v
 return score
song=parse_tja(str(W/'yugen.tja'));score_report={}
for name,suffix in [('Easy','e'),('Normal','n'),('Hard','h'),('Oni','m')]:
 c=song.courses[name];ev=courses[name]['events'];generated=False
 if not c.score_init:
  target={'Easy':400000,'Normal':700000}[name]
  init,diff=min(((i,max(10,round(i/4/10)*10)) for i in range(10,2010,10)),key=lambda pair:abs(estimate(ev,*pair)-target))
  c.score_init,c.score_diff=init,diff;generated=True
 convert_and_write(c,name,str(W/'yugen'))
 put(f'fumen/yugen/yugen_{suffix}.bin',(W/f'yugen_{suffix}.bin').read_bytes())
 count=sum(e['type'] in '1234' for e in ev)
 score_report[name]={'score_init':c.score_init,'score_diff':c.score_diff,'generated_missing_score_fields':generated,'catalog_score_estimate':estimate(ev,c.score_init,c.score_diff),'shinuti_custom':math.ceil(1000000/count/10)*10,'official_scoring_claim':False}
with zipfile.ZipFile('/workspace/taiko-output/TaikoPopTap-1.24.0-skip-tutorial-needs-signing.ipa') as z:
 tables={n:decode_json(z.read(R+'ReadAssets/'+n+'.bin')) for n in ['musicinfo','songinfo','wordlist']}
original=copy.deepcopy(tables)
music=tables['musicinfo']['items'];assert not any(x['id']=='yugen' or x['uniqueId']==192 for x in music)
assert max(x['uniqueId'] for x in music)==191
entry=copy.deepcopy(next(x for x in music if x['id']=='numu10'))
entry.update(uniqueId=192,id='yugen',songFileName='song_yugen',order=max(x['order'] for x in music)+1,genreNo=7,isLock=False,isNew=True,debug=False,temp=False,temp2=False)
for name,key,stars in [('Easy','Easy',5),('Normal','Normal',7),('Hard','Hard',8),('Oni','Mania',10)]:
 entry['star'+key]=stars;entry['branch'+key]=False
 entry['shinuti'+key]=entry['shinuti'+key+'Duet']=score_report[name]['shinuti_custom']
 entry['score'+key]=score_report[name]['catalog_score_estimate']
entry['starUra']=0;entry['branchUra']=False
music.append(entry)
tables['songinfo']['items'].append({'uniqueId':192,'id':'yugen','previewPos':1816,'fumenOffsetPos':0})
words=tables['wordlist']['items'];template=next(x for x in words if x['key']=='song_rot')
for key,value in [('song_yugen','YUGEN NO RAN'),('song_sub_yugen','Tatsh a.k.a. Zeami'),('song_detail_yugen','')]:
 assert not any(x['key']==key for x in words)
 item=copy.deepcopy(template);item['key']=key
 for k in item:
  if k.endswith('Text'):item[k]=value
 words.append(item)
for name,d in tables.items():
 old=original[name]['items'];assert d['items'][:len(old)]==old
 b=encode_json(d);assert decode_json(b)==d
 put('ReadAssets/'+name+'.bin',b)
put('sound/song_yugen.bin',(W/'song_yugen.bin').read_bytes())
(W/'score-policy.json').write_text(json.dumps(score_report,indent=2)+'\n')
(W/'registration.json').write_text(json.dumps({'music_entry':entry,'song_entry':tables['songinfo']['items'][-1],'existing_music_entries_preserved':len(original['musicinfo']['items']),'MusicMax':200,'source_reference':'DataConst.cctor RVA 0x10ee18c; static +0x10 = 0xc8','device_visibility':'NOT TESTED'},indent=2)+'\n')
print('Prepared 3 modified catalogs and 5 new assets; no original songs replaced; ID 192 below MusicMax 200')
print(json.dumps(score_report,indent=2))
