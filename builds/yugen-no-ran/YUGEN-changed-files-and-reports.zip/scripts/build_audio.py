from pathlib import Path
import wave,hashlib,json
from cricodecs import utf,awb,acb
from resource_codec import encrypt,decrypt
W=Path('/workspace/yugen-work')
u=utf.load(str(W/'template.acb'));a=awb.load(u.data(0,'AwbFile'))
a.replace_file(0,str(W/'yugen.hca'));u.set(0,'AwbFile',a.save_bytes())
with wave.open(str(W/'yugen.wav')) as w:frames,rate,channels=w.getnframes(),w.getframerate(),w.getnchannels()
for name,changes in {
 'CueNameTable':{'CueName':'song_yugen'},
 'CueTable':{'Length':round(frames/rate*1000)},
 'WaveformTable':{'NumChannels':channels,'LoopFlag':0,'SamplingRate':rate,'NumSamples':frames},
}.items():
 t=utf.load(u.data(0,name))
 for k,v in changes.items():t.set(0,k,v)
 u.set(0,name,t.build())
u.set(0,'Name','song_yugen');u.set(0,'AcbVolume',1.0)
u.set(0,'AcbGuid',hashlib.sha256(b'custom-yugen-'+(W/'yugen.hca').read_bytes()).digest()[:16])
b=u.build();(W/'song_yugen.acb').write_bytes(b)
a=acb.load(b);assert a.name=='song_yugen' and a.waveform_count==1 and a.cue_count==1
assert a.waveform_bytes(0)==(W/'yugen.hca').read_bytes()
print(a.info());print('Cue plan',a.cue_plan(0))
(W/'song_yugen.bin').write_bytes(encrypt(b));assert decrypt((W/'song_yugen.bin').read_bytes())[:len(b)]==b
print('ACB created, cue and embedded HCA verified',len(b),'samples',frames)
