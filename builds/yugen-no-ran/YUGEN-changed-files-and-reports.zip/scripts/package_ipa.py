from pathlib import Path
import zipfile,hashlib,copy,json,shutil
W=Path('/workspace/yugen-work');src=Path('/workspace/taiko-output/TaikoPopTap-1.24.0-skip-tutorial-needs-signing.ipa')
out=W/'TaikoPopTap-1.24.0-YUGEN-EXPERIMENTAL-needs-signing.ipa'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(src)=='ae6f5943999b0e1db606c8575b32a3c653e2fea087bb12c9d621c6be827539f9'
assets={str(p.relative_to(W/'resources')):p for p in (W/'resources').rglob('*') if p.is_file()}
assert len(assets)==8
with zipfile.ZipFile(src) as z,zipfile.ZipFile(out,'w',allowZip64=True) as d:
 d.comment=z.comment;names=set(z.namelist())
 for info in z.infolist():
  ci=copy.copy(info)
  with d.open(ci,'w',force_zip64=info.file_size>=1<<31) as to:
   if info.filename in assets:
    with assets[info.filename].open('rb') as fr:shutil.copyfileobj(fr,to)
   else:
    with z.open(info) as fr:shutil.copyfileobj(fr,to,1024*1024)
 for n,p in assets.items():
  if n not in names:d.write(p,n,compress_type=zipfile.ZIP_DEFLATED)
print('IPA packed, reading and verifying every entry...',flush=True)
with zipfile.ZipFile(src) as z,zipfile.ZipFile(out) as d:
 assert len(d.namelist())==len(set(d.namelist()))
 assert set(d.namelist())==set(z.namelist())|set(assets)
 changed=[];unchanged=0
 for info in z.infolist():
  n=info.filename
  with z.open(n) as f:before=hashlib.file_digest(f,'sha256').hexdigest()
  with d.open(n) as f:after=hashlib.file_digest(f,'sha256').hexdigest()
  if before!=after:changed.append(n);assert n in assets
  else:unchanged+=1
 for n,p in assets.items():assert d.read(n)==p.read_bytes()
 assert len(changed)==3
 added=sorted(set(d.namelist())-set(z.namelist()));assert len(added)==5
r={'status':'EXPERIMENTAL; NOT ACCEPTANCE-TESTED ON IOS','input_sha256':sha(src),'output_sha256':sha(out),'output_bytes':out.stat().st_size,'changed_existing_entries':changed,'added_entries':added,'unchanged_existing_entries':unchanged,'catalog_preservation':'All original records unchanged; only new entries appended','binary_change':'None relative to tutorial-skip base','signing':'Requires Sideloadly re-signing','ios_clean_install':'NOT RUN','song_visibility_on_device':'NOT RUN','full_playthrough_each_difficulty':'NOT RUN','audio_synchronization_on_device':'NOT RUN','existing_songs_regression_on_device':'NOT RUN'}
(W/'package-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
