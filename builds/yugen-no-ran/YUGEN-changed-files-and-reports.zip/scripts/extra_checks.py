import wave,json,struct
from pathlib import Path
import numpy as np
from tja2fumen.parsers import parse_fumen
from tja2fumen.writers import write_fumen
from resource_codec import decode_json,decrypt
import subprocess
W=Path('/workspace/yugen-work');R=W/'resources/Payload/BNEI0361.app/Data/Raw'
for s in ['e','n','h','m']:
 p=R/f'fumen/yugen/yugen_{s}.bin';f=parse_fumen(str(p));q=W/f'roundtrip_{s}.bin';write_fumen(str(q),f);assert p.read_bytes()==q.read_bytes()
info=decode_json((R/'ReadAssets/musicinfo.bin').read_bytes())['items'];song=next(x for x in info if x['id']=='yugen')
assert len({x['uniqueId'] for x in info})==len(info) and len({x['id'] for x in info})==len(info)
assert song['genreNo']==7 and song['isLock'] is False and song['debug'] is False
assert [song['star'+s] for s in ['Easy','Normal','Hard','Mania']]==[5,7,8,10]
s=next(x for x in decode_json((R/'ReadAssets/songinfo.bin').read_bytes())['items'] if x['id']=='yugen');assert s['uniqueId']==song['uniqueId']
w=decode_json((R/'ReadAssets/wordlist.bin').read_bytes())['items'];assert len({x['key'] for x in w})==len(w)
assert next(x for x in w if x['key']=='song_yugen')['englishUsText']=='YUGEN NO RAN'
raw=decrypt((R/f"sound/{song['songFileName']}.bin").read_bytes())
(W/'padded.acb').write_bytes(raw)
cue=json.loads(subprocess.check_output(['/workspace/taiko-patch-tools/bin/cricodecs',str(W/'padded.acb'),'--cue','--list','--json']))
assert cue['item_count']==1 and cue['items'][0]['cue_name']==song['songFileName'] and cue['items'][0]['cue_id']==0
def pcm(path):
 with wave.open(str(path)) as w:return np.frombuffer(w.readframes(w.getnframes()),dtype='<i2').astype(float).reshape(-1,2)
x=pcm(W/'yugen.wav');y=pcm(W/'ffmpeg-hca.wav')
# FFmpeg exposes raw HCA frames. Remove the header's 128-sample encoder delay.
# FFmpeg's decoder has opposite polarity to CriCodecs; compare with polarity normalization.
y=-y[128:128+len(x)];snr=float(10*np.log10(np.mean(x*x)/np.mean((x-y)**2)));assert snr>25
r={'fumen_byte_roundtrip_all_four':'passed','catalog_id_uniqueness':'passed','catalog_asset_links_all_four':'passed','genre_Namco_7':'passed','unlocked_nondebug_entry':'passed','cue_index_zero_embedded_audio':'passed','original_ogg_to_cri_compensation_samples':128,'ffmpeg_independent_decode_snr_db_polarity_normalized':snr,'limitations':'These are host-side format/PCM tests, not native iOS playback or gameplay.'}
(W/'integration-validation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
