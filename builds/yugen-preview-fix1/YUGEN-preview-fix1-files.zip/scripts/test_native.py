import json,struct,hashlib,sys
from pathlib import Path
from native_probe import Probe
sys.path.insert(0,'/workspace/yugen-work')
from resource_codec import decrypt,encrypt
from cricodecs import utf,acb
W=Path('/workspace/yugen-fix');old=Path('/workspace/yugen-work/song_yugen.acb').read_bytes();fixed=(W/'song_yugen-aligned.acb').read_bytes();orig=Path('/workspace/yugen-work/template.acb').read_bytes()
u=utf.load(old);v=utf.load(fixed)
# Only the outer UTF layout is rebuilt. All logical data, including nested tables and HCA, stays identical.
assert [c.name for c in u.columns]==[c.name for c in v.columns]
for c in u.columns:
 a=u.value(0,c.name);b=v.value(0,c.name)
 if isinstance(a,utf.DataRef):assert u.data(0,c.name)==v.data(0,c.name),c.name
 else:assert a==b,c.name
native=[]
for label,blob,expected in [('original_song_rot',orig,1),('broken_yugen',old,0),('fixed_yugen',fixed,1)]:
 for delta in [0,8,16]:
  p=Probe();base=0x6000000+delta;p.u.mem_write(base,blob)
  ctx=p.call(0xe3eee4,0x4000000,0x4002000,0x1790)
  r=p.call(0xe3f070,ctx,base,len(blob),0)
  rows=struct.unpack('<I',p.u.mem_read(ctx+0x172c,4))[0]
  assert r==expected,(label,delta,r,p.logs)
  if expected:assert rows==0 and all('overflow' not in s for s in p.logs)
  else:assert rows>0 and any('E2015051807' in s for s in p.logs)
  native.append({'input':label,'buffer_alignment_mod32':delta,'native_return':r,'stream_awb_rows_interpreted':rows,'log':p.logs,'expected_result_observed':True})
b=encrypt(fixed);(W/'song_yugen.bin').write_bytes(b);dec=decrypt(b)
p=Probe();p.u.mem_write(0x6000000,dec);ctx=p.call(0xe3eee4,0x4000000,0x4002000,0x1790)
assert p.call(0xe3f070,ctx,0x6000000,len(dec),0)==1
# Independent cue/HCA checks use the path-based reader, without NumPy in this process.
a=acb.load(str(W/'song_yugen-aligned.acb'));plan=a.cue_plan(0)
assert plan.cue_name=='song_yugen' and plan.cue_id==0
assert a.waveform_bytes(0)==Path('/workspace/yugen-work/yugen.hca').read_bytes()
report={'root_cause':'Outer UTF rebuild lost original 32-byte data alignment. Native CRI parser reads StreamAwbHash as a legacy table; tightly packed following data is interpreted as a nonzero stream-AWB row count and causes E2015051807 Stream awb work overflow. Restoring 32-byte alignment keeps the required zero padding and avoids the erroneous count.', 'fix':'Set outer ACB UTF data alignment to 32 before build. No chart, scoring, catalog, HCA or app binary changes.', 'native_test_method':'Unicorn executes original game ARM64 context initializer 0xe3eee4 and ACB parser 0xe3f070; standard libc and error callbacks are emulated. No device or full CRI playback runtime.', 'native_cases':native,'encrypted_resource_roundtrip_native_parser':'passed','cue_id':0,'cue_name':'song_yugen','hca_payload_unchanged':True,'acb_logical_fields_unchanged':True,'fixed_sound_sha256':hashlib.sha256(b).hexdigest(),'device_test':'NOT RUN. User must install and test menu preview and all four charts.', 'acf_warning':'Probe does not register game ACF; identical ACF-not-registered warning occurs for both original and fixed assets. It is not treated as a device result.'}
(W/'native-regression.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
