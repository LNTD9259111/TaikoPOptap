"""Repack the existing experimental YUGEN IPA, changing only its audio bank layout."""
import copy,hashlib,json,zipfile,shutil,sys
from pathlib import Path
sys.path.insert(0,'/workspace/yugen-work')
from resource_codec import decrypt,encrypt
from cricodecs import utf
from native_probe import Probe
W=Path('/workspace/yugen-fix')
SRC=Path('/workspace/yugen-work/TaikoPopTap-1.24.0-YUGEN-EXPERIMENTAL-needs-signing.ipa')
OUT=W/'TaikoPopTap-1.24.0-YUGEN-preview-fix1-needs-signing.ipa'
MEMBER='Payload/BNEI0361.app/Data/Raw/sound/song_yugen.bin'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(SRC)=='934011dde939872db91555811227944b49bd473d5c9ae0fd59cb18c93346243a'
with zipfile.ZipFile(SRC) as z:
 raw=decrypt(z.read(MEMBER));bank=utf.load(raw);bank.set_data_alignment(32);fixed=bank.build();encrypted=encrypt(fixed)
 assert encrypted==(W/'song_yugen.bin').read_bytes()
 with zipfile.ZipFile(OUT,'w',allowZip64=True) as out:
  out.comment=z.comment
  for info in z.infolist():
   with out.open(copy.copy(info),'w',force_zip64=info.file_size>=1<<31) as to:
    if info.filename==MEMBER:to.write(encrypted)
    else:
     with z.open(info) as fr:shutil.copyfileobj(fr,to,1024*1024)
 print('Repacked; checking every member...',flush=True)
 with zipfile.ZipFile(OUT) as out:
  assert out.namelist()==z.namelist();changed=[]
  for n in z.namelist():
   with z.open(n) as f:a=hashlib.file_digest(f,'sha256').hexdigest()
   with out.open(n) as f:b=hashlib.file_digest(f,'sha256').hexdigest()
   if a!=b:changed.append(n)
  assert changed==[MEMBER]
  loaded=decrypt(out.read(MEMBER));p=Probe();p.u.mem_write(0x6000000,loaded)
  ctx=p.call(0xe3eee4,0x4000000,0x4002000,0x1790);assert p.call(0xe3f070,ctx,0x6000000,len(loaded),0)==1
r={'input_sha256':sha(SRC),'output_sha256':sha(OUT),'bytes':OUT.stat().st_size,'changed_members':changed,'unchanged_members':len(z.namelist())-1,'native_parser_on_final_ipa_asset':'passed','device_install_and_preview':'NOT RUN','playthrough_all_four_difficulties':'NOT RUN','signing':'Re-sign with Sideloadly'}
(W/'package-report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
